-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: j8c206.p.ssafy.io    Database: tlens
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `age` int NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `membership` bit(1) NOT NULL,
  `nickname` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,0,'g@g.g','male',_binary '\0','test','$2a$10$O4N6KuFYvxJMMeZN1J9JQex04Rms0EOZ7Dhf23Ekx/DzRQ0IE7aT.'),(2,0,'g@g.g','male',_binary '\0','test1','$2a$10$Pp6rfbCI8dpz6fEHzAGRMO9F9BAAEY.1wwS4AsSri/XGSsZD.nzoC'),(3,0,'lee@lee','male',_binary '\0','잭다니엘','$2a$10$JFk2p.kYp5a9yJt470POhuFj9/QQX.iq/yCxXutW/RF6J.cbT5vjC'),(30,0,'testtest1@gmail.com','female',_binary '\0','testtest1','$2a$10$hXIP1UsVGG.ndosIwVqc2.im3EyxzxvaDiADXP.sEz0bWfsolnPUS'),(51,11,'test@gmail.com','male',_binary '\0','강에디','$2a$10$gjq8wBYjlvjPv9h2HaghouNjfSeVjVepAS1zWqrkMhW6QxkG0j5Gm'),(52,10,'test2@gmail.com','female',_binary '\0','최에디','$2a$10$EmCecWZ/MtH.L8bHqw/Ik.MJsCNiUQm/9CpoPoWLLG1CfSSq1fN0K'),(53,1,'test@gmail.com','female',_binary '\0','test','$2a$10$eKEv/rUKjw33N3.6Dx/m3.q35JSqURpgotOa40VCOs/3k.PVC72w6'),(54,1,'test@gmail.com','male',_binary '\0','test','$2a$10$aUZEuipHeV7V8u9DjhC9SetQc7V8Dkv9QSp2EscQQdh3sTRNl.x1O'),(55,10,'leee@kim','male',_binary '\0','최로이','$2a$10$V4so77AuSvzgTghY.D5ey.uwPNq3YtzgwJUOuMx0v6i.zINBV5xny'),(56,0,'test@gmail.com','male',_binary '\0','test','$2a$10$.CB6NjUHtk9ttG7vQ0RZOu39NFXemSRjObjKLq2pTi5Cz3QLXM9.e'),(57,0,'asdfjkl@gmail.com','female',_binary '\0','test','$2a$10$vXxv7rnWkMJUH4rRHZhQyObQSKzIc2ouLWWC2lzaK7oFiYYdEZiUG'),(58,1,'test1@2.2','male',_binary '\0','testest','$2a$10$eeof3r4usWxcwlX9z26oq.wY44QD0eIPJFbNP4pzY1jtJyQ5g4yYm'),(59,1,'lee@nav.com','male',_binary '\0','fdk','$2a$10$LaT9gK5Mo2RxaRyv8a1oyO2VRe1sL7ZSZeY.Ai9VmkVr30IYMZ9E6'),(60,0,'lee@naver.com','female',_binary '\0','fdka','$2a$10$Q6jmz/AfkHU/yj72DGZgv.cm4Hq4YqsZjn2K38xz8iNFKwBdB3AdO'),(61,27,'qkrtlgud3286@naver.com','male',_binary '\0','시형팍','$2a$10$f0V6a9VruG4Uo.SYJNMDDe7h8FbvSrNI595k06wcCLrrHDEo/hZO6'),(62,194581,'test2@2.2','female',_binary '\0','test2','$2a$10$vAXEZciNtBsvcXzaL2m9e.XoLCzaFCFpn2zlnZI5gOTPrbWCvJUxC'),(63,197387,'test3@2.2','female',_binary '\0','test3','$2a$10$WX5JEl0DVnv.iBHf65xJTunZDf14IdiNyA9uYih8dkympluwgdpZG'),(64,28,'test4@2.2','female',_binary '\0','test4','$2a$10$XlZ5JBYgncoP8hGUYqCG2uC6bsZ1C5HHMiHY7X6NsBqEb/rZuaYlK'),(65,49,'test5@2.2','male',_binary '\0','test5','$2a$10$ofPa2AULlOI2jdb5nI6VL.68CP7fmgAIPvgjwsDkMrYOPa0j4ge6.'),(66,24,'mantest@2.2','male',_binary '\0','man','$2a$10$FvfmlrYFL9PM9K6yQsdaZuyGuZOwLmqoNp8ZvV4obyIaP/LROvyt.'),(67,19,'femaletest@2.2','female',_binary '\0','female','$2a$10$4FI1zr4bHZWw4E.Wd5jQVeSgWeIoLjkI8KejMcDgV74NSB19wQyA6'),(68,62,'test6@2.2','female',_binary '\0','test6','$2a$10$dYVpBbjAx5lEGdInIhJcRu1TOE7Vv1CUbvN8Dk/rq.Za1EtN.dOle'),(77,1,'eddy@eddy','male',_binary '\0','문문문','$2a$10$jlrXNjCdQ8RU08/MpoXf4eSwd8IJO55T7Q2n0quU42ycNXn3e7rXy'),(78,999,'lee@lee','female',_binary '\0','이이이','$2a$10$B0o8.iiSCvFG50hEooo/9.MyYkLGqo3NReIgYs/YXv8IgpcG4OuFK'),(79,1,'lee@lee','male',_binary '\0','임임임','$2a$10$0DlPssYzaAY0v9hs830Yk.NaocTF0j04cCaaNWTJCInFDr10LNtnu'),(82,29,'test3@gmail.com','female',_binary '\0','테스트3','$2a$10$OwTMx/Fh/okUkFmYMPpblOcyabhRl/iIqUSXyNsjRuFitMoKYFah2'),(83,28,'qkrtlgud3288@naver.com','male',_binary '\0','sihyeong','$2a$10$m0qKOXNThEuwiH/djdNe/.hO2Ceglcn0FDkyKsSRG9jrG1iMhgVDu');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07  9:35:30
