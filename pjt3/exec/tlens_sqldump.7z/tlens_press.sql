-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: j8c206.p.ssafy.io    Database: tlens
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `press`
--

DROP TABLE IF EXISTS `press`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `press` (
  `press_id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`press_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `press`
--

LOCK TABLES `press` WRITE;
/*!40000 ALTER TABLE `press` DISABLE KEYS */;
INSERT INTO `press` VALUES (1,'경향신문','https://mimgnews.pstatic.net/image/upload/office_logo/032/2020/09/15/logo_032_6_20200915155035.png'),(2,'서울신문','https://mimgnews.pstatic.net/image/upload/office_logo/081/2022/01/07/logo_081_6_20220107180811.png'),(3,'한겨레','https://mimgnews.pstatic.net/image/upload/office_logo/028/2020/09/15/logo_028_6_20200915190845.png'),(4,'국민일보','https://mimgnews.pstatic.net/image/upload/office_logo/005/2020/09/15/logo_005_6_20200915155137.png'),(5,'세계일보','https://mimgnews.pstatic.net/image/upload/office_logo/022/2020/09/15/logo_022_6_20200915183753.png'),(6,'한국일보','https://mimgnews.pstatic.net/image/upload/office_logo/469/2020/09/15/logo_469_6_20200915191039.png'),(7,'동아일보','https://mimgnews.pstatic.net/image/upload/office_logo/020/2019/01/22/logo_020_6_20190122142722.png'),(8,'조선일보','https://mimgnews.pstatic.net/image/upload/office_logo/023/2020/09/03/logo_023_6_20200903164340.png'),(9,'문화일보','https://mimgnews.pstatic.net/image/upload/office_logo/021/2022/08/04/logo_021_6_20220804125325.png'),(10,'중앙일보','https://mimgnews.pstatic.net/image/upload/office_logo/025/2021/08/24/logo_025_6_20210824123340.png'),(11,'뉴스1','https://mimgnews.pstatic.net/image/upload/office_logo/421/2018/09/19/logo_421_6_20180919151119.png'),(12,'채널A','https://mimgnews.pstatic.net/image/upload/office_logo/449/2020/09/15/logo_449_6_20200915190621.png'),(13,'MBC','https://mimgnews.pstatic.net/image/upload/office_logo/214/2020/09/15/logo_214_6_20200915153641.png'),(14,'TV조선','https://mimgnews.pstatic.net/image/upload/office_logo/448/2020/09/15/logo_448_6_20200915154233.png'),(15,'뉴시스','https://mimgnews.pstatic.net/image/upload/office_logo/003/2019/01/23/logo_003_6_20190123191323.jpg'),(16,'한국경제TV','https://mimgnews.pstatic.net/image/upload/office_logo/215/2020/09/15/logo_215_6_20200915191012.png'),(17,'MBN','https://mimgnews.pstatic.net/image/upload/office_logo/057/2020/09/15/logo_057_6_20200915153924.png'),(18,'YTN','https://mimgnews.pstatic.net/image/upload/office_logo/052/2020/11/17/logo_052_6_20201117112951.png'),(19,'연합뉴스','https://mimgnews.pstatic.net/image/upload/office_logo/001/2020/09/15/logo_001_6_20200915184213.png'),(20,'JTBC','https://mimgnews.pstatic.net/image/upload/office_logo/437/2018/09/19/logo_437_6_20180919153419.png'),(21,'SBS','https://mimgnews.pstatic.net/image/upload/office_logo/055/2020/09/15/logo_055_6_20200915154015.png'),(22,'연합뉴스TV','https://mimgnews.pstatic.net/image/upload/office_logo/422/2020/09/15/logo_422_6_20200915184242.png'),(23,'KBS','https://mimgnews.pstatic.net/image/upload/office_logo/056/2020/09/15/logo_056_6_20200915153508.png'),(24,'SBS Biz','https://mimgnews.pstatic.net/image/upload/office_logo/374/2021/01/07/logo_374_6_20210107162903.png'),(25,'강원도민일보','https://mimgnews.pstatic.net/image/upload/office_logo/654/2022/01/24/logo_654_6_20220124173220.png'),(26,'대구MBC','https://mimgnews.pstatic.net/image/upload/office_logo/657/2022/02/16/logo_657_6_20220216164248.png'),(27,'전주MBC','https://mimgnews.pstatic.net/image/upload/office_logo/659/2022/01/24/logo_659_6_20220124173612.png'),(28,'강원일보','https://mimgnews.pstatic.net/image/upload/office_logo/087/2019/09/02/logo_087_6_20190902111302.png'),(29,'대전일보','https://mimgnews.pstatic.net/image/upload/office_logo/656/2022/01/24/logo_656_6_20220124173440.png'),(30,'CJB청주방송','https://mimgnews.pstatic.net/image/upload/office_logo/655/2022/01/24/logo_655_6_20220124173419.png'),(31,'경기일보','https://mimgnews.pstatic.net/image/upload/office_logo/666/2023/01/05/logo_666_6_20230105135918.png'),(32,'JIBS','https://mimgnews.pstatic.net/image/upload/office_logo/661/2022/01/24/logo_661_6_20220124173713.png'),(33,'부산일보','https://mimgnews.pstatic.net/image/upload/office_logo/082/2020/09/15/logo_082_6_20200915182739.png'),(34,'kbc광주방송','https://mimgnews.pstatic.net/image/upload/office_logo/660/2022/01/24/logo_660_6_20220124173640.png');
/*!40000 ALTER TABLE `press` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07  9:35:33
